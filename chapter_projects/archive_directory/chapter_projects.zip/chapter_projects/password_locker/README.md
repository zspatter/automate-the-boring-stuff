# Password Locker

The password manager program you’ll create in this example isn’t secure, but it offers a basic demonstration of how such programs work.

This script can be run with a command line argument that is the account's name (for example, email or blog). The password associated with the account will be copied to the clipboard so that the user can paste it into a Password field.

This script demonstrates how to automate the retrieval of commonly referenced text.
